//package talabat;
//
//public class History {
//
//    String Date;
//    String Name;
//    int Quantity;
//
//    public History(String Date, String Name, int Quantity) {
//        this.Date = Date;
//        this.Name = Name;
//        this.Quantity = Quantity;
//    }
//
//    public void displayHistory() {
//        System.out.println("Date: " + Date);
//        System.out.println("Name: " + Name);
//        System.out.println("Quantity: " + Quantity);
//        System.out.println("_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_");
//    }
//}
