package talabat;

public class Meal {

    String Name;
    double Price;
    double Calories;
    double Time;
    int Quantity;

    public Meal(String name, double price, double calories, double time, int quantity) {
        Name = name;
        Price = price;
        Calories = calories;
        Time = time;
        Quantity = quantity;
    }
}
